#ifndef INIT_H
#define INIT_H

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>
void interfaceProgram();

void interfaceUser();

void interfacePets();

void format(char *text,char *format,char *final);

#endif //INIT_H