
#include "user.h"
#include "pet.h"
#include "init.h"
int main()
{

    interfaceProgram();
    system("pause");

}